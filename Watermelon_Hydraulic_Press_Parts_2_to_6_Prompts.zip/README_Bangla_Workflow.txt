WATERMELON HYDRAULIC PRESS — ৬ PART CONTINUITY PROMPT PACK

এই ZIP ফাইলে Part 2 থেকে Part 6 পর্যন্ত পাঁচটি সম্পূর্ণ ১০-সেকেন্ডের ইংরেজি ভিডিও প্রম্পট আছে। প্রতিটি প্রম্পটে আলাদা timeline, camera angle, speed ramping, slow motion, transitions, VFX, paper animation এবং sound design দেওয়া হয়েছে।

GOOGLE FLOW WORKFLOW

১. একই Google Flow Project-এ কাজ চালিয়ে যাও।
২. Video → Frames নির্বাচন করো।
৩. আগের পার্টের ভিডিওর একদম শেষ ফ্রেম Save frame / Export frame করে নাও।
৪. পরের পার্টের জন্য সেই ছবিটি Add start frame হিসেবে আপলোড করো।
৫. সম্ভব হলে মূল Watermelon Reference Image-টিও Ingredient/reference হিসেবে রাখো।
৬. সংশ্লিষ্ট PART_x prompt ফাইলের পুরো লেখা পেস্ট করো।
৭. Vertical 9:16 এবং ১০ সেকেন্ড সেট করে Generate করো।
৮. নতুন ভিডিও তৈরি হলে তার শেষ ফ্রেম সংরক্ষণ করে পরের পার্টে ব্যবহার করো।

FRAME CHAIN

Part 1-এর শেষ ফ্রেম → Part 2-এর Start Frame
Part 2-এর শেষ ফ্রেম → Part 3-এর Start Frame
Part 3-এর শেষ ফ্রেম → Part 4-এর Start Frame
Part 4-এর শেষ ফ্রেম → Part 5-এর Start Frame
Part 5-এর শেষ ফ্রেম → Part 6-এর Start Frame

গুরুত্বপূর্ণ:
• প্রতিটি নতুন পার্টে আগের পার্টের প্রকৃত শেষ ফ্রেম ব্যবহার করবে। আগে থেকে বানানো বা অনুমান করা ছবি ব্যবহার করবে না।
• Prompt-এর FINAL FRAME REQUIREMENT অংশটি অনুসরণ করবে।
• Flow সবসময় নিখুঁত continuity নিশ্চিত করে না। Generate করার পর opening frame ও character/machine অবস্থান পরীক্ষা করবে। ভুল হলে একই prompt-এ continuity আরও স্পষ্ট করে পুনরায় generate করবে।
• ছয়টি ভিডিও এডিটিং সফটওয়্যারে জোড়া লাগানোর সময় পার্টগুলোর শুরু ও শেষের অপ্রয়োজনীয় ফ্রেম কেটে continuity মিলিয়ে নেবে।
• Hydraulic motor hum, steel movement, paper rustle এবং character sound-এর একই audio assets/recordings সব পার্টে ব্যবহার করলে sound continuity ভালো হবে।
• এই দৃশ্যটি কাল্পনিক AI animation; বাস্তব শিল্পকারখানার ফুটেজ হিসেবে উপস্থাপন করবে না।

ফাইল তালিকা:
PART_2_First_Contact.txt
PART_3_Pressure_Increases.txt
PART_4_Breaking_Point.txt
PART_5_Juice_Release.txt
PART_6_Final_Reveal.txt
README_Bangla_Workflow.txt

প্রতিটি prompt আলাদা করে সম্পূর্ণ। সংশ্লিষ্ট পার্ট তৈরির সময় পুরো ফাইলের লেখা কপি করবে।
